package com.example;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by kimyongyeon on 2016-12-06.
 */
@Controller
public class HelloController {
    @RequestMapping("/")
    public String hello() {
        return "hello";
    }
}
