package com.ryeon.crudspringbootgradle.controller;

import com.ryeon.crudspringbootgradle.domain.BoardVO;
import com.ryeon.crudspringbootgradle.service.BoardService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.support.SessionStatus;

import javax.validation.Valid;

@Controller
@SessionAttributes("boardVO")
public class BoardController
{
    private static final Logger logger = LoggerFactory.getLogger(BoardController.class);

//	@Autowired
//	private BoardDao boardDao;

    @Autowired
    private BoardService boardService;

    @RequestMapping(value = "/board/list", method = RequestMethod.GET)
    public String list(Model model)
    {
        logger.info("list(Model model)");


        model.addAttribute("boardList", boardService.list());

        logger.info("list(Model model)2 : " + boardService.list().toString());
        return "/board/list";
    }

    @RequestMapping(value ="/board/write", method = RequestMethod.GET)
    public String write(Model model)
    {
        logger.info("write(Model model");

        model.addAttribute("boardVO", new BoardVO());
        return "/board/write";
    }

    @RequestMapping(value = "/board/write", method = RequestMethod.POST)
    public String writer(@Valid BoardVO boardVO, BindingResult bindingResult)
    {
        logger.info("/board/write post");

        if (bindingResult.hasErrors())
        {
            return "/board/write";
        }
        else
        {
            boardService.write(boardVO);
            return "redirect:/board/list";
        }
    }

    @RequestMapping(value = "/board/edit/{seq}", method = RequestMethod.GET)
    public String edit(@PathVariable int seq, Model model)
    {
        logger.info("/board/edit/" + seq + " : get");

        BoardVO boardVO = boardService.read(seq);
        model.addAttribute("boardVO", boardVO);
        return "/board/edit";
    }

    @RequestMapping(value = "/board/edit/{seq}", method = RequestMethod.POST)
    public String edit(@Valid @ModelAttribute BoardVO boardVO, BindingResult result, int pwd, SessionStatus sessionStatus, Model model)
    {
        logger.info("/board/edit/ : post : " + pwd + " , " + boardVO.getPassword());

        if (result.hasErrors())
        {
            return "/board/edit";
        }
        else
        {
            if (boardVO.getPassword() == pwd)
            {
                boardService.edit(boardVO);
                sessionStatus.setComplete();
                return "redirect:/board/list";
            }
            model.addAttribute("msg", "not collect password " + pwd + " , " + boardVO.getPassword());
            return "/board/edit";
        }
    }

    @RequestMapping(value = "/board/read/{seq}", method = RequestMethod.GET)
    public String read(@PathVariable int seq, Model model)
    {
        logger.info("/board/read " + seq);

        model.addAttribute("boardVO", boardService.read(seq));
        return "/board/read";
    }

    @RequestMapping(value = "/board/delete/{seq}", method = RequestMethod.GET)
    public String delete(@PathVariable int seq, Model model)
    {
        logger.info("/board/delete/" + seq + " : get");

        model.addAttribute("seq", seq);
        return "/board/delete";
    }

    @RequestMapping(value = "/board/delete", method = RequestMethod.POST)
    public String delete(int seq, int pwd, Model model)
    {
        logger.info("/board/delete : post");

        BoardVO boardVO = new BoardVO();
        boardVO.setSeq(seq);
        boardVO.setPassword(pwd);

        try {
            boardService.delete(boardVO);
            return "redirect:/board/list";
        } catch(Exception e){
            logger.error(e.toString());
            model.addAttribute("seq", seq);
            model.addAttribute("msg", "비밀번호가 일치하지 않습니다. ");
            return "board/delete";
        }
    }
}
