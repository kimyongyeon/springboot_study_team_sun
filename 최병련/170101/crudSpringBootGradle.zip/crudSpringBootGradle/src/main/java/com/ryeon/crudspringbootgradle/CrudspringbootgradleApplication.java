package com.ryeon.crudspringbootgradle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudspringbootgradleApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudspringbootgradleApplication.class, args);
	}
}
