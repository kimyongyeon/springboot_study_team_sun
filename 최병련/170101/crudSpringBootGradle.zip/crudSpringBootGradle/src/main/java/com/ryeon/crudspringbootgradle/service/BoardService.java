package com.ryeon.crudspringbootgradle.service;

import com.ryeon.crudspringbootgradle.domain.BoardVO;

import java.util.List;

public interface BoardService
{
    public abstract List<BoardVO> list();
    public abstract BoardVO read(int seq);
    public abstract void write(BoardVO boardVO);
    public abstract Boolean delete(BoardVO boardVO);
    public abstract int edit(BoardVO boardVO);
}
