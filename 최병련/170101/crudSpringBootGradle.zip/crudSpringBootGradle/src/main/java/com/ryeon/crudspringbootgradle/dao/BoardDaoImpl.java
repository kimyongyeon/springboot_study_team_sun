package com.ryeon.crudspringbootgradle.dao;

import com.ryeon.crudspringbootgradle.domain.BoardVO;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class BoardDaoImpl implements BoardDao
{
    private static final Logger logger = LoggerFactory.getLogger(BoardDaoImpl.class);

//	@Autowired
//	private SessionFactory sessionFactory;

    @PersistenceContext
    private EntityManager em;

    @Transactional
    @Override
    public int update(BoardVO boardVO)
    {
        int updateResult = em.createQuery("UPDATE BoardVO SET title = :title, content = :content, writer = :writer WHERE seq = :seq AND password = :password")
                .setParameter("title", boardVO.getTitle())
                .setParameter("content", boardVO.getContent())
                .setParameter("writer", boardVO.getWriter())
                .setParameter("seq", boardVO.getSeq())
                .setParameter("password", boardVO.getPassword())
                .executeUpdate();
        logger.info("updateDAO " + updateResult);
        return updateResult;
    }

    @Transactional
    @Override
    public List<BoardVO> list()
    {
        List<BoardVO> boards = em.createQuery("from BoardVO").getResultList();
        return boards;
    }

    @Transactional
    @Override
    public int delete(BoardVO boardVO)
    {
        Query query = em.createQuery("delete from BoardVO where seq = :seq AND password = :password");
        query.setParameter("seq", boardVO.getSeq());
        query.setParameter("password", boardVO.getPassword());
        return query.executeUpdate();
    }

    @Transactional
    @Override
    public int deleteAll()
    {
        Query query = em.createNativeQuery("delete from BoardVO");
        return query.executeUpdate();
    }

    @Transactional
    @Override
    public void insert(BoardVO boardVO)
    {
        em.persist(boardVO);
    }

    @Transactional
    @Override
    public BoardVO select(int seq)
    {
        return em.find(BoardVO.class, seq);
    }

    @Transactional
    @Override
    public int updateReadCount(int seq)
    {
        int updateResult = em.createQuery("UPDATE BoardVO SET cnt = cnt + 1 WHERE seq = :seq")
                .setParameter("seq", seq)
                .executeUpdate();
        logger.info("updateReadCount : " + updateResult);
        return updateResult;
    }
}

