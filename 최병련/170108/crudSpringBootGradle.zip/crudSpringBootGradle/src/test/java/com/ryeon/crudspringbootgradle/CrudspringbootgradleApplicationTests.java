package com.ryeon.crudspringbootgradle;

import com.ryeon.crudspringbootgradle.controller.BoardController;
import com.ryeon.crudspringbootgradle.dao.BoardDao;
import com.ryeon.crudspringbootgradle.dao.BoardDaoImpl;
import com.ryeon.crudspringbootgradle.domain.BoardVO;
import com.ryeon.crudspringbootgradle.service.BoardService;
import javafx.application.Application;
import org.junit.*;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.WebIntegrationTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.PropertySource;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.junit4.SpringRunner;

import javax.annotation.Resource;

import static org.junit.Assert.assertEquals;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = CrudspringbootgradleApplication.class)
public class CrudspringbootgradleApplicationTests
{

	@Autowired
	private BoardService boardService;

	@BeforeClass
	public static void beforeClass()
	{
		System.out.println("====================\n beforeClass \n ==================");
	}

	@AfterClass
	public static void afterClass()
	{
		System.out.println("====================\n afterClass \n ==================");
	}

	@Before
	public void init()
	{
		System.out.println("====================\n test init \n ==================");

		BoardVO boardVO = new BoardVO();
		boardVO.setContent("content");
		boardVO.setPassword(0000);
		boardVO.setTitle("title");
		boardVO.setWriter("writer");
		boardVO.setCnt(0);
		boardService.write(boardVO);
	}

	@Test
	public void execute()
	{
		System.out.println("====================\n test execute \n ==================");

		assertEquals(1, boardService.list().size());
		assertEquals("content", boardService.read(1).getContent());
		assertEquals(0000, boardService.read(1).getPassword());
		assertEquals("title", boardService.read(1).getTitle());
		assertEquals("writer", boardService.read(1).getWriter());
		boardService.delete(boardService.read(1));
		assertEquals(0, boardService.list().size());
	}

	@After
	public void exit()
	{
		System.out.println("====================\n test exit \n ==================");
	}

}
