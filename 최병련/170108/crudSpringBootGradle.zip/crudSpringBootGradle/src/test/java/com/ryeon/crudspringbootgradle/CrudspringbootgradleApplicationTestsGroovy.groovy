package com.ryeon.crudspringbootgradle

import org.junit.runner.RunWith
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner
import spock.lang.Specification


class CrudspringbootgradleApplicationTestsGroovy extends Specification
{
    def "Stub 사용법"() {
        given:
        List list = Stub()
        list.size() >> 3

        expect:
        list.size() == 3
    }
}
