package com.ryeon.crudspringbootgradle.service;

import com.ryeon.crudspringbootgradle.dao.BoardDao;
import com.ryeon.crudspringbootgradle.domain.BoardVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BoardServiceImpl implements BoardService
{
    @Autowired
    BoardDao boardDao;

    @Override
    public List<BoardVO> list()
    {
        return boardDao.list();
    }

    @Override
    public BoardVO read(int seq)
    {
        boardDao.updateReadCount(seq);
        return boardDao.select(seq);
    }

    @Override
    public void write(BoardVO boardVO)
    {
        boardDao.insert(boardVO);
    }

    @Override
    public Boolean delete(BoardVO boardVO)
    {
        try {
            boardDao.delete(boardVO);
            return true;
        } catch (Exception e)
        {
            return false;
        }
    }

    @Override
    public int edit(BoardVO boardVO)
    {
        return boardDao.update(boardVO);
    }
}
