package com.ryeon.crudspringboot.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.ryeon.crudspringboot.dao.BoardDao;
import com.ryeon.crudspringboot.domain.BoardVO;

@RestController
public class BoardRestController 
{
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	
	@Autowired
	private BoardDao boardDao;
	
	@RequestMapping(value = "/rest/board/list", method = RequestMethod.GET)
	public List<BoardVO> restList()
	{
		logger.info("restList");
		
		List<BoardVO> boardVO = boardDao.findAll();
		
		return boardVO;
	}
}
