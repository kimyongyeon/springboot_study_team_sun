package com.ryeon.crudspringboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ryeon.crudspringboot.dao.HelloDao;
import com.ryeon.crudspringboot.domain.HelloVO;

@RestController
public class HelloRestController 
{
	@Autowired
	private HelloDao helloDao;
	
	@RequestMapping("/add")
	public HelloVO add(HelloVO hello)
	{
		HelloVO helloData = helloDao.save(hello);
		return helloData;
	}
	
	@RequestMapping("/list")
	public List<HelloVO> list(Model model)
	{
		List<HelloVO> helloList = helloDao.findAll();
		return helloList;
	}
	
	@RequestMapping("/")
	public String index()
	{
		return "helloworld!";
	}
}
