package com.ryeon.crudspringboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ryeon.crudspringboot.dao.BoardDao;
import com.ryeon.crudspringboot.domain.BoardVO;

@Service
public class BoardService implements BoardServiceImpl
{
	@Autowired
	BoardDao boardDao;
	
	@Override
	public List<BoardVO> list() 
	{
		return boardDao.findAll();
	}
	
	@Override
	public BoardVO read(int seq) 
	{
		return boardDao.findOne(seq);
	}
	
	@Override
	public void write(BoardVO boardVO) 
	{
		boardDao.save(boardVO);
	}
	
	@Override
	public Boolean delete(BoardVO boardVO) 
	{
		try {
			boardDao.delete(boardVO);
			return true;
		} catch (Exception e) 
		{
			return false;
		}
	}
}
