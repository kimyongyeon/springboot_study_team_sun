package com.ryeon.crudspringboot.service;

import java.util.List;

import com.ryeon.crudspringboot.domain.BoardVO;

public interface BoardServiceImpl 
{
	public abstract List<BoardVO> list();
	public abstract BoardVO read(int seq);
	public abstract void write(BoardVO boardVO);
	public abstract Boolean delete(BoardVO boardVO);
}
