package com.ryeon.crudspringboot.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ryeon.crudspringboot.domain.BoardVO;

public interface BoardDao extends JpaRepository<BoardVO, Integer>
{
	
}
