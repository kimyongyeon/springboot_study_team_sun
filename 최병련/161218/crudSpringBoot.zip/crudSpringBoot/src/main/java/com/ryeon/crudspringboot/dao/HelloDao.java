package com.ryeon.crudspringboot.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ryeon.crudspringboot.domain.HelloVO;

public interface HelloDao extends JpaRepository<HelloVO, Integer>
{
	
}
