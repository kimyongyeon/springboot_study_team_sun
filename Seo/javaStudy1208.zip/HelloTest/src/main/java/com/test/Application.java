package com.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.*;

@Configuration
@ComponentScan
public class Application {
	
	   @Bean
	    MessageService mockMessageService() {
	        return new MessageService() {
	            public String getMessageService() {
	              return "Hello World!";
	            }

	        };
	    }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(" ===  test === ");
		
		ApplicationContext app = new AnnotationConfigApplicationContext(Application.class);
		MessagePrinter mp = app.getBean(MessagePrinter.class);
		mp.getMessage();
	}

}




