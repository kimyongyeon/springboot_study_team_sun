package com.test;

import org.springframework.stereotype.Component;


public class MessageServiceMail implements MessageService{

	@Override
	public String getMessageService() {
		// TODO Auto-generated method stub
		return "Test MessageServiceMail" ;
	}

}
