package com.test;

public interface MessageService {
	
	public String getMessageService();

}
