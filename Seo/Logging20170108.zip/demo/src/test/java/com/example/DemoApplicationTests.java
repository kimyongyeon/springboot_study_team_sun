package com.example;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;


@RunWith(SpringRunner.class)
@SpringBootTest
public class DemoApplicationTests {
	
	@Autowired
	private ProductDao pd;
	
	@Test
	public void selectProductTest() 
	{

		try {
			
			System.out.println("=== selectProductTest ===");
			System.out.println(pd.selectProduct());
			System.out.println("=== selectProductTest ===");
			//System.out.println(pd.selectProductList().toString());
			System.out.println("=== selectProductTest ===");
			System.out.println(pd.selectProductListByMcode("M00101").toString());
			System.out.println("=== selectProductTest ===");
			//System.out.println(pd.selectProductListByMcode("").toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void contextLoads() {
	}

}
