package com.example;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductController {
	
	Logger log = LoggerFactory.getLogger(ProductController.class);
	
	@Autowired 
	private ProductDao pd;
	
	@RequestMapping("/")
	String home()
	{
		// 1. SpringBoot-web에  slf4j-api가 포함되어 있음.
		//     1-1. 실행시 변경 java -jar app.jar --debug
		//     1-2  properties에 설정 필요 logging.level.com.example=trace
		//     1-3  logback.xml 에 설정 
		//  http://docs.spring.io/spring-boot/docs/1.4.2.RELEASE/reference/html/

		log.error("error Message!");
		log.warn("warn Message!");
		log.info("info Message!");
		log.debug("debug Message!");
		log.trace("trace Message!");
		
		return "Hello world";
	}

	@RequestMapping("/log")
	String log() throws Exception
	{
		log.trace("== trace Message! ==");
		System.out.println("test log ");
		pd.selectProductListByMcode("M00101");

		
		return "sqlformatting log";
	}
}
