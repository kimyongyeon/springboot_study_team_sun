package com.example;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import net.sf.log4jdbc.Log4jdbcProxyDataSource;


@Configuration
public class AppConfig {
	
	@Autowired
	DataSourceProperties dataSourceProperties;
	DataSource dataSource;

	@Bean
	DataSource realDataSource()
	{
		
		System.out.println("test realDataSource Mapping!!!!!!!!");
		System.out.println(this.dataSourceProperties.getUrl());
		System.out.println(this.dataSourceProperties.getUsername());
		DataSourceBuilder factory = DataSourceBuilder
				.create(this.dataSourceProperties.getClassLoader())
				.url(this.dataSourceProperties.getUrl())
				.username(this.dataSourceProperties.getUsername())
				.password(this.dataSourceProperties.getPassword());
				//.driverClassName(this.dataSourceProperties.getDriverClassName());
		
		this.dataSource = factory.build();
		
		return new Log4jdbcProxyDataSource(this.dataSource);
		
		
	}
	
	/*@Bean
	@Primary
	DataSource dataSource(){
		return new Log4jdbcProxyDataSource(this.dataSource);
	}*/
}
