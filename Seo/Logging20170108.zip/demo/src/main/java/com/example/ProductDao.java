package com.example;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ProductDao {

	public String selectProduct() throws Exception;
	
	public List<ProductVo> selectProductList() throws Exception;
	
	public List<ProductVo> selectProductListByMcode(String value) throws Exception;

}
