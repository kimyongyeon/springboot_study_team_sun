package com.example;

import lombok.Data;

@Data
public class ProductVo {
	
	private String m_code;
	private String prod_id;
	private String prod_nm;

}
