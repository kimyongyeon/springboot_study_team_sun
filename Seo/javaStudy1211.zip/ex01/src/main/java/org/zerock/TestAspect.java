package org.zerock;

import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class TestAspect {

	/*// 특정 어노테이션이 명시된 모든 메써드의 실행 전후로 끼어들 수 있다.
	@Around("@annotation(someAnnotation)")
	public Object doSomethingAround(final ProceedingJoinPoint joinPoint, final SomeAnnotation someAnnotation) {

	    // 대상 메써드 실행 전 끼어들어 실행할 로직을 작성

	    Object result = joinPoint.proceed();

	    // 대상 메써드 실행 후 끼어들어 실행할 로직을 작성, 리턴 값을 가공할 수 있다.

	    return result;
	}*/
}